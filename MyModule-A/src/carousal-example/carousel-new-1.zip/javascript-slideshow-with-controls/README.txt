A Pen created at CodePen.io. You can find this one at http://codepen.io/SitePoint/pen/WwqvqB.

 

Forked from [Yaphi](http://codepen.io/yaphi1/)'s Pen [Basic JavaScript Slideshow without jQuery](http://codepen.io/yaphi1/pen/PNOZRr/).