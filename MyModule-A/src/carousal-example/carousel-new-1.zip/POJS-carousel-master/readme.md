# Carousel
A re-usable carousel class written in Vanilla JS.

## Features:
* infinite scroll
* navigation breadcrumbs
* swipe detection